# VoAny SMS 接收修补包 v2

此补丁针对日志中实际出现的下行 `PID=0x7F / DCS=0xF6`。当前 VoAny 代码把非零 PID 当作不可显示短信并回 `RP-ERROR`；而这是 class-2 SIM 数据下载短信，应交给选中的 SIM/UICC 处理后再回网络。补丁新增这一条 SMS-PP / ENVELOPE 路径，并保留原有普通短信解析与发送路径。

## 证据边界

日志证明这版 APK 收到了三条 `PID=0x7F / DCS=0xF6`，却把它们作为不支持的短信拒收；它们属于 SIM 数据下载短信，可能是运营商或业务平台的配置/信令消息，不能仅凭这点断言它们就是 Google、ENC 或普通 +86 验证码。日志里没有出现普通短信被解析并保存的记录，因此普通 MT SMS 是否进入了 IMS 网关仍未被这份日志判定。

## 应用到 GitHub Actions 构建

1. 解压本 ZIP，把 `VoAny_SMS_receive_patch_v2` 目录中的文件上传到你 fork 仓库根目录下的 `patch/VoAny_SMS_receive_patch_v2/`。不要覆盖仓库源码。
2. 在工作流 checkout 之后、Gradle 构建之前加入：

```yaml
      - name: Apply VoAny SMS receive patch
        run: python3 patch/VoAny_SMS_receive_patch_v2/apply_sms_fix.py --repo "$GITHUB_WORKSPACE"
```

3. 保持原有 Gradle 构建步骤，运行原来的 workflow 并安装生成的 APK。

安装器只接受已核对过的上游版本或之前 v1 补丁版本；如果源码版本不同会停止且不改文件。它会备份被替换的源码到 `.voany-sms-backup/`。可先加 `--check` 仅验证兼容性。

## 验证结果

- 26 项普通短信/PID/状态报告回归测试通过。
- 38 项 SMS-PP BER、SIM 状态字及 RP ACK/ERROR 回包测试通过。
- 本次新增 AIDL、Shizuku SIM bridge、SIM-PP 解码/回包和 SMS session 代码通过 Android 36 API 编译检查。
- 这不是完整 APK 构建，也没有在你的手机上做过真实 SIM/运营商端到端测试。补丁安装后仍需重新测试一条普通 +86 短信和一条验证码；若仍收不到，导出的日志能帮助区分短信是否进入 APK。

请勿把验证码、短信正文、完整电话号码或 SIM 鉴权数据发到公开 issue。排查日志只需保留 `MT SMS`、`RP-ACK/RP-ERROR`、`SIM SW` 等事件行并打码个人信息。
