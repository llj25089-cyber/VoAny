package org.voany.android.sms;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/** Bounded metadata only: no SMS body, sender, phone number, or SIM credentials. */
public final class SmsReceiveDiagnostics {
    private final SharedPreferences preferences;
    private final String prefix,session=UUID.randomUUID().toString();
    public SmsReceiveDiagnostics(Context context,int subscription,boolean lwip){
        preferences=context.getSharedPreferences("voany",Context.MODE_PRIVATE);
        prefix="smsDiag.v3."+subscription+".";
        synchronized(SmsReceiveDiagnostics.class){
            preferences.edit().putString(prefix+"session",session)
                .putLong(prefix+"started",System.currentTimeMillis())
                .putString(prefix+"backend",lwip ? "lwIP" : "Android VPN")
                .putInt(prefix+"requests",0).putInt(prefix+"data",0)
                .putString(prefix+"last","None").putString(prefix+"reply","None").apply();
        }
    }
    private boolean current(){return session.equals(preferences.getString(prefix+"session",""));}
    public void message(){synchronized(SmsReceiveDiagnostics.class){if(current())preferences.edit().putInt(prefix+"requests",preferences.getInt(prefix+"requests",0)+1).apply();}}
    public void data(){synchronized(SmsReceiveDiagnostics.class){if(current())preferences.edit().putInt(prefix+"data",preferences.getInt(prefix+"data",0)+1).apply();}}
    public void event(String value){record("last",value);}
    public void reply(String value){record("reply",value);}
    private void record(String key,String value){
        synchronized(SmsReceiveDiagnostics.class){
            if(current())preferences.edit().putString(prefix+key,time(System.currentTimeMillis())+" / "+value).apply();
        }
    }
    private static String time(long value){return new SimpleDateFormat("MM-dd HH:mm:ss",Locale.ROOT).format(new Date(value));}
    public static String summary(Context context,int subscription){
        SharedPreferences p=context.getSharedPreferences("voany",Context.MODE_PRIVATE);String key="smsDiag.v3."+subscription+".";
        synchronized(SmsReceiveDiagnostics.class){
            long started=p.getLong(key+"started",0);
            if(started==0)return "SMS receive patch: v3\nNo SMS session started";
            return "SMS receive patch: v3\nBackend: "+p.getString(key+"backend","")
                +" / session "+time(started)
                +"\nSIP MESSAGE / RP-DATA: "+p.getInt(key+"requests",0)+" / "+p.getInt(key+"data",0)
                +"\nLast incoming: "+p.getString(key+"last","None")
                +"\nLast RP reply: "+p.getString(key+"reply","None");
        }
    }
}
