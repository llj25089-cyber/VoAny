#!/usr/bin/env python3
"""Run the standalone SMS codec regression suite using JDK 17+."""
import argparse
from pathlib import Path
import shutil
import subprocess
import tempfile

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repo',type=Path,help='VoAny checkout to test; defaults to the replacement files in this package')
    args=parser.parse_args()
    package=Path(__file__).resolve().parent.parent
    root=args.repo.resolve() if args.repo else package
    codec=root/'VoAnyLib/src/main/java/org/voany/android/sms/SmsCodec.java'
    java=shutil.which('java')
    if not java:
        raise SystemExit('JDK 17+ is required; java was not found')
    with tempfile.TemporaryDirectory(prefix='voany-sms-tests-') as out:
        subprocess.run([java,'-m','jdk.compiler/com.sun.tools.javac.Main','-encoding','UTF-8','-d',out,str(codec),str(root/'VoAnyLib/src/main/java/org/voany/android/sms/SmsPpDownload.java'),str(root/'VoAnyLib/src/main/java/org/voany/android/sms/SmsReplyTarget.java'),str(package/'tests/SmsCodecRegression.java'),str(package/'tests/SmsPpDownloadRegression.java'),str(package/'tests/SmsReplyTargetRegression.java')],check=True)
        subprocess.run([java,'-cp',out,'SmsCodecRegression'],check=True)
        subprocess.run([java,'-cp',out,'SmsPpDownloadRegression'],check=True)
        subprocess.run([java,'-cp',out,'SmsReplyTargetRegression'],check=True)
        diagnostic_sources=[root/'VoAnyLib/src/main/java/org/voany/android/sms/SmsReceiveDiagnostics.java',package/'tests/SmsDiagnosticsRegression.java',package/'tests/stubs/android/content/Context.java',package/'tests/stubs/android/content/SharedPreferences.java']
        subprocess.run([java,'-m','jdk.compiler/com.sun.tools.javac.Main','-encoding','UTF-8','-d',out]+[str(p) for p in diagnostic_sources],check=True)
        subprocess.run([java,'-cp',out,'SmsDiagnosticsRegression'],check=True)

if __name__=='__main__':
    main()
