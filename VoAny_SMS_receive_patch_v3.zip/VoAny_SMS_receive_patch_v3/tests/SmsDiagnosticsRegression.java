import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;
import java.util.Map;
import org.voany.android.sms.SmsReceiveDiagnostics;

public final class SmsDiagnosticsRegression {
    private static int passed;
    private static final class MemoryContext extends Context {
        final Prefs preferences=new Prefs();
        public SharedPreferences getSharedPreferences(String name,int mode){return preferences;}
    }
    private static final class Prefs implements SharedPreferences {
        final Map<String,Object> values=new HashMap<>();
        public String getString(String k,String d){return (String)values.getOrDefault(k,d);}
        public int getInt(String k,int d){return (Integer)values.getOrDefault(k,d);}
        public long getLong(String k,long d){return (Long)values.getOrDefault(k,d);}
        public Editor edit(){return new Editor(){
            final Map<String,Object> changes=new HashMap<>();
            public Editor putString(String k,String v){changes.put(k,v);return this;}
            public Editor putInt(String k,int v){changes.put(k,v);return this;}
            public Editor putLong(String k,long v){changes.put(k,v);return this;}
            public void apply(){values.putAll(changes);}
        };}
    }
    private static void check(String name,boolean good){if(!good)throw new AssertionError(name);passed++;System.out.println("PASS "+name);}
    public static void main(String[] args)throws Exception{
        MemoryContext context=new MemoryContext();
        check("unstarted session is explicit",SmsReceiveDiagnostics.summary(context,1).contains("No SMS session started"));
        SmsReceiveDiagnostics old=new SmsReceiveDiagnostics(context,1,false);
        check("new session identifies backend and resets counts",SmsReceiveDiagnostics.summary(context,1).contains("Backend: Android VPN") && SmsReceiveDiagnostics.summary(context,1).contains("0 / 0"));
        old.message();
        check("SIP MESSAGE and RP-DATA counts are separate",SmsReceiveDiagnostics.summary(context,1).contains("1 / 0"));
        old.data();old.event("text saved");old.reply("RP-ACK / SIP 202");
        String before=SmsReceiveDiagnostics.summary(context,1);
        check("last reception and last reply remain separately visible",before.contains("1 / 1") && before.contains("text saved") && before.contains("RP-ACK / SIP 202"));
        SmsReceiveDiagnostics fresh=new SmsReceiveDiagnostics(context,1,true);
        old.message();old.data();old.event("stale event");old.reply("stale reply");
        String after=SmsReceiveDiagnostics.summary(context,1);
        check("old session cannot pollute a new session",after.contains("Backend: lwIP") && after.contains("0 / 0") && !after.contains("stale") && !after.contains("text saved"));
        fresh.message();fresh.data();fresh.event("new event");
        new SmsReceiveDiagnostics(context,2,false).event("other SIM event");
        String first=SmsReceiveDiagnostics.summary(context,1),second=SmsReceiveDiagnostics.summary(context,2);
        check("SIM diagnostics remain isolated",first.contains("new event") && !first.contains("other SIM") && second.contains("other SIM event") && second.contains("0 / 0"));
        Thread[] writers=new Thread[4];
        for(int i=0;i<writers.length;i++){writers[i]=new Thread(()->{for(int n=0;n<100;n++){fresh.message();fresh.data();}});writers[i].start();}
        for(Thread writer:writers)writer.join();
        check("concurrent events preserve both counters",SmsReceiveDiagnostics.summary(context,1).contains("401 / 401"));
        System.out.println("RESULT "+passed+"/"+passed+" passed");
    }
}
