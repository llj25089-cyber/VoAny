package org.voany.android.sms;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;

/** SMS-PP download framing: TS 31.111 7.1.1, TS 23.040 9.2.2.1a, TS 24.011 7.3. */
public final class SmsPpDownload {
    public static final class Download {
        public final int reference,pid,dcs;
        private final byte[] envelope;
        private Download(int reference,int pid,int dcs,byte[] envelope){
            this.reference=reference;this.pid=pid;this.dcs=dcs;this.envelope=envelope;
        }
        public byte[] envelope(){return envelope.clone();}
    }
    /** Returns null for messages which must continue through the normal text/status path. */
    public static Download decode(byte[] rpdu){
        SmsCodec.Rp rp=SmsCodec.parseRp(rpdu);
        if(rp.type!=1 || rp.tpdu.length<3 || (rp.tpdu[0]&3)!=0)return null;
        byte[] p=rp.tpdu;
        int addressLength=p[1]&255,pidAt=3+(addressLength+1)/2;
        if(pidAt+2>p.length)throw new IllegalArgumentException("Truncated SMS-DELIVER header");
        int pid=p[pidAt]&255,dcs=p[pidAt+1]&255;
        boolean class2=(((dcs&0xc0)==0 && (dcs&0x10)!=0) || (dcs&0xf0)==0xf0) && (dcs&3)==2;
        if((pid!=0x7f && pid!=0x7c) || !class2)return null;
        if(addressLength>20 || (p[2]&0x80)==0 || pidAt+10>p.length)
            throw new IllegalArgumentException("Invalid SMS-PP fixed header");
        int alphabet=(dcs&0xc0)==0 ? (dcs>>2)&3 : (dcs&4)==0 ? 0 : 1;
        if(((dcs&0xc0)==0 && (dcs&0x20)!=0) || alphabet==3)
            throw new IllegalArgumentException("Unsupported SMS-PP coding");
        int udl=p[pidAt+9]&255,bytes=alphabet==0 ? (udl*7+7)/8 : udl;
        if(bytes>140 || pidAt+10+bytes!=p.length)
            throw new IllegalArgumentException("Invalid SMS-PP user-data length");
        if((p[0]&0x40)!=0 && (bytes==0 || (p[pidAt+10]&255)+1>bytes))
            throw new IllegalArgumentException("Truncated SMS-PP user-data header");
        // Keep the original RP originator (SMSC) and TPDU bytes, including any security header.
        int smscLength=rpdu[2]&255;
        ByteArrayOutputStream body=new ByteArrayOutputStream();
        body.write(0x82);body.write(2);body.write(0x83);body.write(0x81);
        if(smscLength!=0){body.write(0x06);length(body,smscLength);body.write(rpdu,3,smscLength);}
        body.write(0x8b);length(body,p.length);body.write(p,0,p.length);
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        out.write(0xd1);length(out,body.size());byte[] data=body.toByteArray();out.write(data,0,data.length);
        return new Download(rp.reference,pid,dcs,out.toByteArray());
    }
    private static void length(ByteArrayOutputStream out,int value){
        if(value<0 || value>255)throw new IllegalArgumentException("SMS-PP envelope too large");
        if(value>=128)out.write(0x81);out.write(value);
    }
    public static String hex(byte[] value){
        char[] digits="0123456789ABCDEF".toCharArray(),out=new char[value.length*2];
        for(int i=0;i<value.length;i++){int b=value[i]&255;out[i*2]=digits[b>>4];out[i*2+1]=digits[b&15];}
        return new String(out);
    }
    private static byte[] unhex(String value){
        if(value==null || value.length()<4 || value.length()>322 || (value.length()&1)!=0)
            throw new IllegalArgumentException("Missing or oversized SIM envelope response");
        byte[] out=new byte[value.length()/2];
        for(int i=0;i<out.length;i++){
            int a=Character.digit(value.charAt(i*2),16),b=Character.digit(value.charAt(i*2+1),16);
            if(a<0 || b<0)throw new IllegalArgumentException("Invalid SIM envelope response");
            out[i]=(byte)((a<<4)|b);
        }
        return out;
    }
    /** Status words are the final TWO bytes of TelephonyManager's hex response. */
    public static int statusWord(String response){
        byte[] raw=unhex(response);return ((raw[raw.length-2]&255)<<8)|(raw[raw.length-1]&255);
    }
    /** A transport acknowledgement does not assert that a SIM command was authenticated/executed. */
    public static byte[] reply(Download d,String response){
        if(d==null)throw new IllegalArgumentException("Not an SMS-PP download");
        byte[] raw=unhex(response);int sw1=raw[raw.length-2]&255,sw2=raw[raw.length-1]&255;
        byte[] payload=Arrays.copyOf(raw,raw.length-2);
        // TS 31.111 Rel-16 7.1.1.1: warning/6F status words are acknowledged with the SIM response.
        boolean ack=(sw1==0x90 && sw2==0) || sw1==0x91 || sw1==0x62 || sw1==0x63 || sw1==0x6f;
        if(!ack)return failure(d.reference,sw1==0x93 && sw2==0 ? 0xd4 : 0xd5,payload,d);
        if(payload.length==0)return SmsCodec.ack(d.reference);
        return wrap(d.reference,true,report(d,0,payload));
    }
    public static byte[] failure(int reference){return failure(reference,0xd5,new byte[0],null);}
    private static byte[] failure(int reference,int cause,byte[] payload,Download d){
        return wrap(reference,false,report(d,cause,payload));
    }
    private static byte[] report(Download d,int failure,byte[] payload){
        if(payload.length>(failure==0 ? 159 : 158))throw new IllegalArgumentException("SIM response TP-UD too large");
        ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(0);
        if(failure!=0)out.write(failure);
        out.write(payload.length==0 ? 0 : 7);
        if(payload.length!=0){
            if(d==null)throw new IllegalArgumentException("Missing SMS-PP coding");
            out.write(d.pid);out.write(d.dcs);
            boolean gsm7=((d.dcs&0x8c)==0) || ((d.dcs&0xf4)==0xf0);
            out.write(gsm7 ? payload.length*8/7 : payload.length);out.write(payload,0,payload.length);
        }
        return out.toByteArray();
    }
    private static byte[] wrap(int reference,boolean ack,byte[] tpdu){
        if(reference<0 || reference>255)throw new IllegalArgumentException("Invalid RP reference");
        ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(ack ? 2 : 4);out.write(reference);
        if(!ack){out.write(1);out.write(111);} // RP protocol cause; TP failure belongs in the report.
        out.write(0x41);out.write(tpdu.length);out.write(tpdu,0,tpdu.length);return out.toByteArray();
    }
    private SmsPpDownload(){}
}
