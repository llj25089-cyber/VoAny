#!/usr/bin/env python3
"""Install the reviewed v3 SMS receive changes into a matching VoAny checkout."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile


def digest(value):
    return hashlib.sha256(value).hexdigest()


def atomic_write(path, value):
    mode = stat.S_IMODE(path.stat().st_mode) if path.exists() else 0o644
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix="." + path.name + ".",
                                     suffix=".tmp", delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(value)
    try:
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path,
                        help="Existing VoAny repository root")
    parser.add_argument("--check", action="store_true",
                        help="Verify compatibility without changing files")
    args = parser.parse_args()
    root = args.repo.resolve()
    package = Path(__file__).resolve().parent
    if root == package or not (root / "VoAnyApp").is_dir() or not any(
            (root / name).is_file() for name in ("settings.gradle", "settings.gradle.kts")):
        raise SystemExit("Target is not a VoAny repository root; no files changed.")
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    plan = []
    for relative, info in manifest["files"].items():
        target = root / relative
        if not target.resolve().is_relative_to(root):
            raise SystemExit("Unsafe target path: " + relative)
        source = package / relative
        if digest(source.read_bytes()) != info["patched_sha256"]:
            raise SystemExit("Patch package checksum mismatch: " + relative)
        if info["new"]:
            if target.exists():
                if digest(target.read_bytes()) == info["patched_sha256"]:
                    print("Already patched: " + relative)
                    continue
                raise SystemExit("Refusing to overwrite existing file: " + relative)
            plan.append((relative, target, None, source.read_bytes()))
            continue
        if not target.is_file():
            raise SystemExit("Missing " + relative + "; no files changed.")
        current = target.read_bytes()
        if digest(current) == info["patched_sha256"]:
            print("Already patched: " + relative)
            continue
        if digest(current) not in info["accepted_sha256"]:
            raise SystemExit("Different source revision: " + relative + "; no files changed.")
        plan.append((relative, target, current, source.read_bytes()))
    if args.check:
        print("Compatible. " + str(len(plan)) + " file(s) would change; no files changed.")
        return
    if not plan:
        print("All v3 SMS receive source files are already patched.")
        return
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    backup = root / ".voany-sms-backup" / stamp
    for relative, target, current, replacement in plan:
        if current is not None:
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
    written = []
    try:
        for relative, target, current, replacement in plan:
            atomic_write(target, replacement)
            written.append((target, current))
    except BaseException:
        for target, current in reversed(written):
            if current is None:
                target.unlink(missing_ok=True)
            else:
                atomic_write(target, current)
        raise
    print("Applied " + str(len(plan)) + " files. Existing files backed up under " + str(backup))


if __name__ == "__main__":
    main()
