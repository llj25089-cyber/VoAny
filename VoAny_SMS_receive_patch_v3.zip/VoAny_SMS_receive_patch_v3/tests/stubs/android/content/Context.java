package android.content;
/** JVM test double; never included in the Android source set. */
public abstract class Context {
    public static final int MODE_PRIVATE=0;
    public abstract SharedPreferences getSharedPreferences(String name,int mode);
}
