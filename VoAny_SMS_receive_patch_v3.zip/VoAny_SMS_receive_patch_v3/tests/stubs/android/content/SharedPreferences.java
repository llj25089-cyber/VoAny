package android.content;
/** Minimal JVM test double; production API signatures are checked separately. */
public interface SharedPreferences {
    String getString(String key,String fallback);
    int getInt(String key,int fallback);
    long getLong(String key,long fallback);
    Editor edit();
    interface Editor {
        Editor putString(String key,String value);
        Editor putInt(String key,int value);
        Editor putLong(String key,long value);
        void apply();
    }
}
