package org.voany.android.sms;

import java.util.ArrayList;
import java.util.List;

/** TS 24.341 5.3.2.4: address the RP report to the asserted IP-SM-GW. */
public final class SmsReplyTarget {
    public final String uri,source;
    private SmsReplyTarget(String uri,String source){this.uri=uri;this.source=source;}

    public static SmsReplyTarget select(List<String> asserted,String from,String domain){
        String telephone=null;
        if(asserted!=null)for(String header:asserted)for(String value:addresses(header)){
            String uri=uri(value,domain,false);
            if(uri==null)continue;
            if(!valueUri(value,false).regionMatches(true,0,"tel:",0,4))return new SmsReplyTarget(uri,"P-Asserted-Identity");
            if(telephone==null)telephone=uri;
        }
        if(telephone!=null)return new SmsReplyTarget(telephone,"P-Asserted-Identity");
        String fallback=uri(from,domain,true);
        if(fallback==null)throw new IllegalArgumentException("No usable SMS report target");
        return new SmsReplyTarget(fallback,"From fallback");
    }
    private static List<String> addresses(String header){
        List<String> out=new ArrayList<>();if(header==null || header.indexOf('\r')>=0 || header.indexOf('\n')>=0)return out;
        boolean quoted=false,escaped=false;int angle=0,start=0;
        for(int i=0;i<header.length();i++){
            char ch=header.charAt(i);
            if(escaped){escaped=false;continue;}
            if(quoted && ch=='\\'){escaped=true;continue;}
            if(ch=='"'){quoted=!quoted;continue;}
            if(!quoted){if(ch=='<')angle++;else if(ch=='>')angle--;else if(ch==',' && angle==0){out.add(header.substring(start,i));start=i+1;}}
            if(angle<0)return new ArrayList<>();
        }
        if(!quoted && angle==0)out.add(header.substring(start));
        return out;
    }
    private static String valueUri(String value,boolean from){
        if(value==null || value.indexOf('\r')>=0 || value.indexOf('\n')>=0)return "";
        value=value.trim();int left=value.indexOf('<'),right=value.indexOf('>');
        if(left>=0)return right>left && value.indexOf('<',left+1)<0 && value.indexOf('>',right+1)<0 ? value.substring(left+1,right).trim() : "";
        if(right>=0)return "";
        return from ? value.split(";",2)[0].trim() : value;
    }
    private static String uri(String value,String domain,boolean from){
        String uri=valueUri(value,from);
        if(uri.regionMatches(true,0,"tel:",0,4)){
            if(domain==null || !domain.matches("[A-Za-z0-9.-]{1,253}"))return null;
            try{return "sip:"+SmsCodec.number(uri.substring(4))+"@"+domain+";user=phone";}
            catch(IllegalArgumentException e){return null;}
        }
        if(uri.regionMatches(true,0,"sips:",0,5))uri="sips:"+uri.substring(5);
        else if(uri.regionMatches(true,0,"sip:",0,4))uri="sip:"+uri.substring(4);
        return uri.matches("sips?:[^\\s<>\"\\\\,]+") ? uri : null;
    }
}
