# VoAny SMS 接收补丁 v3

本版修复已经核实的接收兼容缺口，并在 Settings 中加入可截图的接收状态。这是包含 v1/v2 内容的累积源码补丁，基于上游 `pccr10001/VoAny` 的 `997e1d5`，需要继续用原 GitHub Actions 工作流编译 APK。

## 修正内容与证据边界

- 支持日志中的 `PID=0x41 / DCS=0xC8`：记录消息等待提示状态并回确认，按协议处理提示内容。同时支持 D8 的 GSM7 文字与 E8 的 UCS2 文字。提示状态记录在应用本地，本版未实现 SIM EFMWIS 同步或系统语音信箱图标。
- 下行 RP 回执优先发往 `P-Asserted-Identity` 声明的网关；没有可用声明时保留 From 回退，保留 In-Reply-To 关联。
- Settings 状态卡增加版本、连接时间、实际后端、SIP MESSAGE / RP-DATA 计数、最近接收处理结果与最近回执结果。按 SIM 和本次 SMS 会话分别记录，旧连接结果不会覆盖新连接。

新增状态仅含时间、计数、编码和处理阶段，不含短信正文、电话号码或 SIM 鉴权数据。

已有日志证明 C8 提示消息到达 APK 后被拒收；截图显示 Android VPN 下 ePDG 已连接、SIP 已注册。现有证据不能证明提示消息就是 TEST02、TEST03 或验证码，也不能确定它是否阻塞普通短信。是否能解决新短信未达，仍需手机实测；没有把 ESP 丢包日志直接认定为验证码丢失的原因。

## 使用原 GitHub Actions 工作流构建

1. 把 ZIP 原样上传到 fork 仓库根目录，文件名保持为 `VoAny_SMS_receive_patch_v3.zip`。
2. 打开 `.github/workflows/build-voany.yml`，把原来应用 v1/v2 的补丁步骤替换为以下内容，放在 checkout 之后、Gradle 编译之前：

```yaml
      - name: Apply VoAny SMS receive patch v3
        run: |
          unzip -q -o "$GITHUB_WORKSPACE/VoAny_SMS_receive_patch_v3.zip" -d "$RUNNER_TEMP/voany-sms-v3"
          python3 "$RUNNER_TEMP/voany-sms-v3/VoAny_SMS_receive_patch_v3/apply_sms_fix.py" --repo "$GITHUB_WORKSPACE"
```

3. 保留其他工作流步骤，包括此前处理过的 upstream、strongSwan、OpenSSL 准备步骤和 `./gradlew :VoAnyApp:assembleDebug --stacktrace`。
4. 提交修改，运行原工作流，从 Artifacts 下载并安装生成的 APK。

安装器接受匹配的原版、v1/v2 或 v3 文件；版本不匹配会在写入前停止。旧源码备份到 `.voany-sms-backup/`。加 `--check` 可仅检查兼容性。旧 patch 目录可以保留，但工作流应使用上面的 v3 应用步骤，避免随后再应用旧补丁。

## 安装后验证

1. 在 Settings 重新启动服务并等到 READY，保持当前 Android VPN 模式。
2. 确认状态卡出现 `SMS receive patch: v3`、`Backend: Android VPN`，session 时间为本次连接时间。
3. 用 +86 号码向 ENC 号码发一条 `TEST04`，记下北京时间，等待约 60 秒。
4. 截图 Settings 的完整状态卡；文字较长时可分两张。Messages 可点 `Refresh inbox` 刷新。

| 状态 | 可以说明什么 |
| --- | --- |
| `SIP MESSAGE / RP-DATA: 0 / 0` | 本次会话尚无 MESSAGE 进入短信处理入口；不能区分上游未投递与更早的传输问题。 |
| 前一个计数增加、RP-DATA 仍为 0 | 进入的可能只是发信 RP 回执等消息，不能证明收到普通短信。 |
| RP-DATA 增加，出现 `TPDU rejected` | 下行进入 APK 后解析失败。 |
| `message waiting indication` | 收到提示消息，不能当作测试文字或验证码已经到达。 |
| `Text saved to inbox` | 完整文字短信已写入 VoAny 收件箱。 |
| `RP-ACK / SIP 200` 或 `202` | 收信确认请求被 SIP 网关接受，需结合接收状态判断对应内容。 |

## 已完成的验证

- 102 项独立回归测试通过：短信编码 36、SMS-PP 38、回执寻址 21、会话诊断 7。
- 上游原有 SmsCodecTest 的 14 项 JUnit 测试通过，总计 116 项自动测试。
- 复现 v2 对有效 C8 消息的拒收；修正后的向量测试通过。
- 接收 session、编码、回执寻址、诊断和原有 SmsStore 等代码通过 Android 36 API 编译检查。IMS 注册和 SIM bridge 依赖使用编译桩，这不是完整 APK 构建。
- 原版 `997e1d5`、v2 升级、仅检查、重复安装、未知源码拒绝、损坏补丁拒绝共 6 项安装检查通过。
- 未进行真实手机和运营商端到端测试。

有 JDK 17+ 的环境可运行：

```sh
python3 tests/run_tests.py
```

`tests/stubs/` 仅供 JVM 诊断测试，不在 Android 模块源码目录内，不会打进 APK。验证摘要见 `VALIDATION.txt`。

## 协议依据

- TS 23.038 第 4 节，C/D/E 组消息等待提示与文字编码：
  https://www.etsi.org/deliver/etsi_ts/123000_123099/123038/18.00.00_60/ts_123038v180000p.pdf
- TS 24.341 第 5.3.2.4 节，RP 回执的 IP-SM-GW 目标和 In-Reply-To：
  https://www.etsi.org/deliver/etsi_ts/124300_124399/124341/18.00.00_60/ts_124341v180000p.pdf
