import java.util.Arrays;
import java.util.Collections;
import org.voany.android.sms.SmsReplyTarget;

public final class SmsReplyTargetRegression {
    private static int passed;
    private static void check(String name,String expected,String source,String from,String... asserted){
        SmsReplyTarget target=SmsReplyTarget.select(Arrays.asList(asserted),from,"ims.example");
        if(!expected.equals(target.uri) || !source.equals(target.source))throw new AssertionError(name+": unexpected target");
        passed++;System.out.println("PASS "+name);
    }
    public static void main(String[] args){
        String gateway="sip:msg.ims.example",from="<sip:other.ims.example>;tag=1";
        check("asserted gateway wins over From",gateway,"P-Asserted-Identity",from,"<"+gateway+">");
        check("quoted display name with comma",gateway,"P-Asserted-Identity",from,"\"Gateway, one\" <"+gateway+">");
        check("SIP identity wins over a tel identity in the same header",gateway,"P-Asserted-Identity",from,"<tel:+12345>, <"+gateway+">");
        check("SIP identity wins across multiple asserted headers",gateway,"P-Asserted-Identity",from,"<tel:+12345>","<"+gateway+">");
        check("asserted tel identity is converted","sip:+12345@ims.example;user=phone","P-Asserted-Identity",from,"<tel:+12345>");
        check("SIPS identity is preserved","sips:msg.ims.example","P-Asserted-Identity",from,"<sips:msg.ims.example>");
        check("URI parameters inside brackets remain intact",gateway+";user=phone","P-Asserted-Identity",from,"<"+gateway+";user=phone>");
        check("bare asserted URI parameters remain intact",gateway+";transport=tcp","P-Asserted-Identity",from,gateway+";transport=tcp");
        check("URI schemes are case-insensitive",gateway,"P-Asserted-Identity",from,"SIP:msg.ims.example");
        check("uppercase tel identity does not preempt SIP",gateway,"P-Asserted-Identity",from,"<TEL:+12345>, <"+gateway+">");
        check("absent assertion uses From","sip:other.ims.example","From fallback",from);
        check("unsupported assertion uses From","sip:other.ims.example","From fallback",from,"<http://example.invalid>");
        check("malformed assertion uses From","sip:other.ims.example","From fallback",from,"<sip:bad");
        check("From tel identity is converted","sip:+12345@ims.example;user=phone","From fallback","<tel:+12345>;tag=1");
        check("bare From tag is removed","sip:other.ims.example","From fallback","sip:other.ims.example;tag=1");
        check("injected asserted header is ignored","sip:other.ims.example","From fallback",from,"<sip:bad>\r\nInjected: x");
        for(String bad:new String[]{null,"", "<http://invalid>","<sip:bad>\r\nInjected: x","<sip:bad space>"}){
            try{SmsReplyTarget.select(Collections.emptyList(),bad,"ims.example");throw new AssertionError("Invalid From accepted");}
            catch(IllegalArgumentException expected){passed++;}
        }
        System.out.println("RESULT "+passed+"/"+passed+" passed");
    }
}
