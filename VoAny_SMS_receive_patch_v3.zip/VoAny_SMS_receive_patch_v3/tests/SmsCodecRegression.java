import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import org.voany.android.sms.SmsCodec;

/** Fixed SMS-DELIVER/STATUS-REPORT vectors; no Android SDK or modem required. */
public final class SmsCodecRegression {
    private static final String OA="0A912143658709";
    private static final String TIME="62019141345223";
    private static final String HELLO="05E8329BFD06";
    private static int passed;
    private interface Check { void run() throws Exception; }
    private static void test(String name,Check check)throws Exception{
        try{check.run();passed++;System.out.println("PASS "+name);}
        catch(Throwable e){throw new AssertionError(name+": "+e,e);}
    }
    private static void eq(Object expected,Object actual){
        if(!expected.equals(actual))throw new AssertionError("Expected "+expected+", got "+actual);
    }
    private static void yes(boolean value){if(!value)throw new AssertionError("Expected true");}
    private static byte[] hex(String s){
        if(s.length()%2!=0)throw new IllegalArgumentException();
        byte[] b=new byte[s.length()/2];
        for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(s.substring(2*i,2*i+2),16);
        return b;
    }
    private static String hex(byte[] b){
        StringBuilder s=new StringBuilder();for(byte v:b)s.append(String.format("%02X",v&255));return s.toString();
    }
    private static byte[] deliver(int pid,int dcs,String payload){
        return hex("04"+OA+String.format("%02X%02X",pid,dcs)+TIME+payload);
    }
    private static void text(int pid){
        SmsCodec.Deliver d=SmsCodec.deliver(deliver(pid,0,HELLO));
        eq("hello",d.text);eq("+1234567890",d.sender);eq(pid,d.pid);eq(0,d.dcs);
        yes(!d.silent && !d.statusReport);
        eq(Instant.parse("2026-10-19T06:43:25Z").toEpochMilli(),d.timestamp);
    }
    private static void reject(byte[] pdu,String contains){
        try{SmsCodec.deliver(pdu);throw new AssertionError("Malformed or unsupported SMS accepted");}
        catch(IllegalArgumentException e){yes(e.getMessage().contains(contains));}
    }
    public static void main(String[] args)throws Exception{
        test("PID 00 ordinary GSM7",()->text(0));
        test("PID 3F text gateway fallback",()->text(0x3f));
        test("PID 41 optional replacement fallback",()->text(0x41));
        test("observed PID 41 DCS C8 is an active voicemail indication",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0x41,0xc8,HELLO));
            yes(d.messageWaiting && d.waitingActive && d.silent);eq(0,d.waitingType);eq("",d.text);
        });
        test("C8 accepts zero-length user data",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0x41,0xc8,"00"));
            yes(d.messageWaiting && d.waitingActive && d.silent);eq("",d.text);
        });
        test("C0 clears the indication without displaying text",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0,0xc0,"00"));
            yes(d.messageWaiting && !d.waitingActive && d.silent);eq(0,d.waitingType);
        });
        test("MWI indication types remain distinct",()->{
            for(int type=0;type<4;type++){
                SmsCodec.Deliver d=SmsCodec.deliver(deliver(0,0xc8|type,"00"));
                eq(type,d.waitingType);yes(d.messageWaiting && d.waitingActive && d.silent);
            }
        });
        test("D8 stores accompanying GSM7 text",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0,0xd8,HELLO));
            eq("hello",d.text);yes(d.messageWaiting && d.waitingActive && !d.silent);
        });
        test("E8 stores accompanying UCS2 text",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0,0xe8,"046D4B8BD5"));
            eq("测试",d.text);yes(d.messageWaiting && d.waitingActive && !d.silent);
        });
        test("MWI GSM7 header preserves concatenation",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(hex("44"+OA+"00D8"+TIME+"0D06080412340201E8329BFD06"));
            eq("hello",d.text);eq(0x1234,d.concat);eq(1,d.index);eq(2,d.total);yes(d.messageWaiting);
        });
        test("ordinary text is not marked as MWI",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0,0,HELLO));
            yes(!d.messageWaiting);eq(-1,d.waitingType);
        });
        test("truncated MWI data is rejected",()->reject(deliver(0x41,0xc8,"05E832"),"Truncated"));
        test("odd UCS2 MWI data is rejected",()->reject(deliver(0,0xe8,"019A"),"Odd UTF16"));
        test("PID 5E obsolete fallback",()->text(0x5e));
        test("PID 80 reserved fallback",()->text(0x80));
        test("PID C0 service-centre-specific fallback",()->text(0xc0));
        test("PID 3F UCS2 Chinese verification text",()->{
            // Independent UTF-16BE vector, not SmsCodec.submit() output.
            byte[] body="验证码123456".getBytes(StandardCharsets.UTF_16BE);
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0x3f,8,String.format("%02X",body.length)+hex(body)));
            eq("验证码123456",d.text);eq(0x3f,d.pid);eq(8,d.dcs);
        });
        test("alphanumeric sender",()->{
            // Six GSM7 septets 'Google' occupy eleven useful semi-octets.
            byte[] pdu=hex("040BD0C7F7FBCC2E033F00"+TIME+HELLO);
            SmsCodec.Deliver d=SmsCodec.deliver(pdu);eq("Google",d.sender);eq("hello",d.text);
        });
        test("short-code sender",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(hex("0405812200F03F00"+TIME+HELLO));
            eq("22000",d.sender);eq("hello",d.text);
        });
        test("nonzero PID Unicode multipart header",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(hex("44"+OA+"3F08"+TIME+"0C0500032A02019A8C8BC17801"));
            eq("验证码",d.text);eq(42,d.concat);eq(2,d.total);eq(1,d.index);eq(0x3f,d.pid);
        });
        test("type 0 is silent",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0x40,0,HELLO));
            yes(d.silent);eq("",d.text);eq(0x40,d.pid);
        });
        test("type 0 binary payload is not interpreted",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(deliver(0x40,0xf6,"04DEADBEEF"));
            yes(d.silent);eq("",d.text);
        });
        test("type 0 still requires a complete fixed header",()->
            reject(hex("04"+OA+"4000"),"Truncated SMS PDU"));
        test("SIM download with class 2 remains unsupported",()->
            reject(deliver(0x7f,0xf6,"04DEADBEEF"),"PID=0x7F DCS=0xF6"));
        test("SIM download PID outside class 2 follows ordinary text rule",()->text(0x7f));
        test("device depersonalization is not displayed as text",()->
            reject(deliver(0x7e,0x11,HELLO),"PID=0x7E DCS=0x11"));
        test("ME download remains unsupported",()->reject(deliver(0x7d,0,HELLO),"PID=0x7D"));
        test("ANSI R-DATA remains unsupported",()->reject(deliver(0x7c,0,HELLO),"PID=0x7C"));
        test("device triggering remains unsupported",()->reject(deliver(0x48,0,HELLO),"PID=0x48"));
        test("binary ordinary SMS remains unsupported",()->reject(deliver(0,4,"01FF"),"Binary SMS not supported"));
        test("truncated nonzero-PID SMS is rejected with metadata",()->{
            byte[] pdu=deliver(0x3f,0,HELLO);
            reject(Arrays.copyOf(pdu,pdu.length-1),"PID=0x3F DCS=0x00");
        });
        test("odd UCS2 payload is rejected",()->reject(deliver(0x3f,8,"019A"),"Odd UTF16 SMS length"));
        test("trailing bytes remain rejected",()->reject(deliver(0x3f,0,HELLO+"00"),"Trailing SMS PDU bytes"));
        test("status reports still decode",()->{
            SmsCodec.Deliver d=SmsCodec.deliver(hex("0209"+OA+TIME+TIME+"00"));
            yes(d.statusReport);eq(9,d.reference);eq(0,d.status);eq("+1234567890",d.sender);
        });
        test("outgoing GSM7 bytes remain unchanged",()->{
            List<SmsCodec.Part> parts=SmsCodec.submit("+1234567890","hello",17,9,true);
            eq(1,parts.size());eq("21090A912143658709000005E8329BFD06",hex(parts.get(0).tpdu));
        });
        test("network RP envelope and acknowledgement remain compatible",()->{
            byte[] pdu=deliver(0x3f,0,HELLO);
            ByteArrayOutputStream b=new ByteArrayOutputStream();
            b.write(hex("010707912160130300F400"));b.write(pdu.length);b.write(pdu);
            SmsCodec.Rp rp=SmsCodec.parseRp(b.toByteArray());
            eq(1,rp.type);eq(7,rp.reference);eq("+12063130004",rp.origin);
            eq("hello",SmsCodec.deliver(rp.tpdu).text);eq("0207",hex(SmsCodec.ack(rp.reference)));
        });
        System.out.println("RESULT "+passed+"/"+passed+" passed");
    }
}
