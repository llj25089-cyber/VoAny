import org.voany.android.sms.SmsCodec;

/** Reproduces the restrictive nonzero-PID rejection in the unmodified upstream codec. */
public final class BaselineProbe {
    private static byte[] hex(String s){byte[] b=new byte[s.length()/2];for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return b;}
    public static void main(String[] args){
        byte[] pdu=hex("040A9121436587093F006201914134522305E8329BFD06");
        try{System.out.println("DECODED "+SmsCodec.deliver(pdu).text);}
        catch(IllegalArgumentException e){System.out.println("REJECTED "+e.getMessage());System.exit(2);}
    }
}
