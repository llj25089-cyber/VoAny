import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import org.voany.android.sms.SmsCodec;
import org.voany.android.sms.SmsPpDownload;

public final class SmsPpDownloadRegression {
    private static int passed;
    private interface Check{void run()throws Exception;}
    private static void test(String name,Check check)throws Exception{
        try{check.run();passed++;System.out.println("PASS "+name);}
        catch(Throwable e){throw new AssertionError(name+": "+e,e);}
    }
    private static void eq(Object a,Object b){if(!a.equals(b))throw new AssertionError(a+" != "+b);}
    private static void yes(boolean a){if(!a)throw new AssertionError();}
    private static byte[] hex(String s){byte[] b=new byte[s.length()/2];for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return b;}
    private static final String TP="040A9121436587097FF66201914134522304DEADBEEF";
    private static byte[] rp(String tpdu){return rp(hex(tpdu),true);}
    private static byte[] rp(byte[] tpdu,boolean smsc){
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] prefix=hex(smsc ? "010707912160130300F400" : "01070000");
        out.write(prefix,0,prefix.length);out.write(tpdu.length);out.write(tpdu,0,tpdu.length);return out.toByteArray();
    }
    private static SmsPpDownload.Download download(){return SmsPpDownload.decode(rp(TP));}
    private static void reject(Check c){try{c.run();throw new AssertionError("Accepted invalid input");}catch(IllegalArgumentException expected){}catch(Exception e){throw new AssertionError(e);}}
    public static void main(String[] args)throws Exception{
        test("recorded PID/DCS classified as SIM download",()->{
            SmsPpDownload.Download d=download();eq(7,d.reference);eq(127,d.pid);eq(246,d.dcs);
        });
        test("golden BER envelope preserves raw SMSC and TPDU",()->
            eq("D125820283810607912160130300F48B16"+TP,SmsPpDownload.hex(download().envelope())));
        test("absent SMSC omits address TLV",()->
            eq("D11C820283818B16"+TP,SmsPpDownload.hex(SmsPpDownload.decode(rp(hex(TP),false)).envelope())));
        test("envelope getter does not expose mutable bytes",()->{
            SmsPpDownload.Download d=download();byte[] v=d.envelope();v[0]=0;eq(209,d.envelope()[0]&255);
        });
        test("ordinary GSM7 remains text",()->yes(SmsPpDownload.decode(rp(TP.replace("7FF6","0000").replace("04DEADBEEF","05E8329BFD06")))==null));
        test("PID 7F outside class 2 remains text",()->yes(SmsPpDownload.decode(rp(TP.replace("7FF6","7F00")))==null));
        test("class-2 ordinary PID is not an envelope command",()->yes(SmsPpDownload.decode(rp(TP.replace("7FF6","00F6")))==null));
        test("class-2 ANSI R-DATA follows Android SIM path",()->eq(124,SmsPpDownload.decode(rp(TP.replace("7FF6","7CF6"))).pid));
        test("binary DCS 16 is accepted",()->eq(22,SmsPpDownload.decode(rp(TP.replace("7FF6","7F16"))).dcs));
        test("GSM7 class-2 DCS accepts packed payload",()->eq(242,SmsPpDownload.decode(rp(TP.replace("7FF6","7FF2").replace("04DEADBEEF","05E8329BFD06"))).dcs));
        test("status report bypasses SIM path",()->yes(SmsPpDownload.decode(rp("02090A912143658709620191413452236201914134522300"))==null));
        test("RP ACK bypasses SIM path",()->yes(SmsPpDownload.decode(hex("0307"))==null));
        test("MO RP DATA is never forwarded to SIM",()->{byte[] raw=rp(TP);raw[0]=0;yes(SmsPpDownload.decode(raw)==null);});
        test("mismatching UDL is rejected before SIM call",()->reject(()->SmsPpDownload.decode(rp(TP.replace("04DEADBEEF","05DEADBEEF")))));
        test("trailing data is rejected before SIM call",()->reject(()->SmsPpDownload.decode(rp(TP+"00"))));
        test("truncated fixed header rejected",()->reject(()->SmsPpDownload.decode(rp("040A9121436587097FF6"))));
        test("invalid UDHI length rejected",()->reject(()->SmsPpDownload.decode(rp("44"+TP.substring(2)))));
        test("compressed class-2 is rejected",()->reject(()->SmsPpDownload.decode(rp(TP.replace("7FF6","7F36")))));
        test("BER lengths use 81 form when envelope exceeds 127",()->{
            byte[] tp=hex(TP.substring(0,TP.length()-10)+"70"+String.join("",java.util.Collections.nCopies(112,"00")));
            byte[] env=SmsPpDownload.decode(rp(tp,true)).envelope();eq(0x81,env[1]&255);eq(env.length-3,env[2]&255);
        });
        test("BER lengths use 81 form for large TPDU",()->{
            byte[] tp=hex(TP.substring(0,TP.length()-10)+"8C"+String.join("",java.util.Collections.nCopies(140,"00")));
            byte[] env=SmsPpDownload.decode(rp(tp,true)).envelope();eq(0x81,env[1]&255);eq(0x8b,env[16]&255);eq(0x81,env[17]&255);eq(tp.length,env[18]&255);
        });
        test("9000 yields bare RP ACK",()->eq("0207",SmsPpDownload.hex(SmsPpDownload.reply(download(),"9000"))));
        test("91 proactive status yields RP ACK",()->eq("0207",SmsPpDownload.hex(SmsPpDownload.reply(download(),"910F"))));
        test("SIM response returned in deliver report with PID/DCS",()->eq("0207410900077FF604DEADBEEF",SmsPpDownload.hex(SmsPpDownload.reply(download(),"DEADBEEF9000"))));
        test("status word follows payload",()->eq(0x9000,SmsPpDownload.statusWord("DEADBEEF9000")));
        test("warning 62 acknowledged per TS31.111 Rel16",()->eq("0207410600077FF601AA",SmsPpDownload.hex(SmsPpDownload.reply(download(),"AA6283"))));
        test("warning 63 acknowledged per TS31.111 Rel16",()->eq("0207",SmsPpDownload.hex(SmsPpDownload.reply(download(),"6300"))));
        test("6F status acknowledged per TS31.111 Rel16",()->eq("0207",SmsPpDownload.hex(SmsPpDownload.reply(download(),"6F00"))));
        test("9300 has TP toolkit-busy D4 and RP protocol cause 111",()->eq("0407016F410300D400",SmsPpDownload.hex(SmsPpDownload.reply(download(),"9300"))));
        test("unsupported SIM command produces D5",()->eq("0407016F410300D500",SmsPpDownload.hex(SmsPpDownload.reply(download(),"6D00"))));
        test("no SIM result cannot produce ACK",()->eq("0407016F410300D500",SmsPpDownload.hex(SmsPpDownload.failure(7))));
        test("failure payload preserved with PID and DCS",()->eq("0407016F410700D5077FF601AA",SmsPpDownload.hex(SmsPpDownload.reply(download(),"AA6A80"))));
        test("GSM7 response UDL uses septets",()->{
            SmsPpDownload.Download d=SmsPpDownload.decode(rp(TP.replace("7FF6","7FF2").replace("04DEADBEEF","05E8329BFD06")));
            eq("0207410C00077FF20800112233445566",SmsPpDownload.hex(SmsPpDownload.reply(d,"001122334455669000")));
        });
        test("SIM response accepts lowercase hex",()->eq(0x9000,SmsPpDownload.statusWord("aabb9000")));
        test("empty result rejected",()->reject(()->SmsPpDownload.reply(download(),"")));
        test("odd hex result rejected",()->reject(()->SmsPpDownload.reply(download(),"90000")));
        test("non-hex result rejected",()->reject(()->SmsPpDownload.reply(download(),"GG9000")));
        test("oversized response rejected",()->reject(()->SmsPpDownload.reply(download(),String.join("",java.util.Collections.nCopies(160,"00"))+"9000")));
        test("RP wrappers parse with the matching reference",()->{
            SmsCodec.Rp ack=SmsCodec.parseRp(SmsPpDownload.reply(download(),"AA9000"));eq(2,ack.type);eq(7,ack.reference);eq("00077FF601AA",SmsPpDownload.hex(ack.tpdu));
            SmsCodec.Rp err=SmsCodec.parseRp(SmsPpDownload.reply(download(),"9300"));eq(4,err.type);eq(111,err.cause);eq(7,err.reference);eq("00D400",SmsPpDownload.hex(err.tpdu));
        });
        System.out.println("RESULT "+passed+"/"+passed+" passed");
    }
}
